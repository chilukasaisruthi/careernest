@echo off
setlocal
cd /d "%~dp0"
title CareerNest Job Portal
echo ======================================
echo          CareerNest Job Portal
echo ======================================
echo.
if not exist "package.json" (
  echo ERROR: package.json is missing.
  echo Please run this file from the extracted CareerNest project folder.
  pause
  exit /b 1
)
if not exist "app.js" (
  echo ERROR: app.js is missing from this folder.
  pause
  exit /b 1
)
if not exist "node_modules" (
  echo Installing project dependencies for first run...
  call npm install
  if errorlevel 1 (
    echo.
    echo Dependency installation failed. Check your internet connection and Node.js installation.
    pause
    exit /b 1
  )
)
echo Starting CareerNest...
echo Keep this window open while using the website.
echo.
call npm start
echo.
echo CareerNest stopped. Read the error above if startup failed.
pause
