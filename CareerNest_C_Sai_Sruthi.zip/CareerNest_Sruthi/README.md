# CareerNest — Online Job Portal
**Project owner: C. Sai Sruthi**

CareerNest is a job portal built with HTML, CSS, JavaScript, Node.js, Express, and MySQL.

## Features
- Add, view, search, filter, update, and delete job listings
- Upload company images and preview them
- Responsive pages for home, all jobs, job details, posting, editing, and deleting
- MySQL database storage through Express API routes

## Run on Windows
1. Extract this ZIP.
2. Open the `CareerNest_Sruthi` folder in VS Code.
3. Start MySQL Server.
4. Open `bloom_edit/schema.sql` in MySQL Workbench and execute it.
5. Open VS Code Terminal in the `CareerNest_Sruthi` folder.
6. Run `npm install`.
7. Run `npm start`.
8. Open `http://localhost:3000` in Chrome. Keep the terminal open.

## Database
The database name remains `bloomhire` to keep the supplied backend and SQL setup compatible. The default MySQL user is `root` and password is `root`; change the fallback in `bloom_edit/app.js` if your local MySQL password is different.

## Project files
- `app.js` — root launcher
- `bloom_edit/app.js` — Express server and MySQL API
- `bloom_edit/public/` — website pages, CSS, JavaScript, and images
- `bloom_edit/schema.sql` — database and table setup
