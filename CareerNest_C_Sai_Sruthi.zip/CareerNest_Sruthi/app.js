// Root launcher: allows `node app.js` and `npm start` from the extracted project folder.
require("./bloom_edit/app.js");
