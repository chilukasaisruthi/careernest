# CareerNest — Online Job Portal
**Project owner: C. Sai Sruthi**

## Features
- Add, view, edit, and delete job listings
- Search and filter jobs by location, skill, and salary
- Upload company images with preview
- Responsive interface using HTML, CSS, and JavaScript
- Express API with MySQL database

## Setup
1. Extract the ZIP and open the `CareerNest_Sruthi` folder in VS Code.
2. Start MySQL Server.
3. Run `schema.sql` in MySQL Workbench.
4. In VS Code terminal, run `npm install` and then `npm start`.
5. Open `http://localhost:3000` in Chrome.
6. Keep the terminal running while using the website.

If your MySQL password is not `root`, update the fallback password in `app.js`.
The database remains named `bloomhire` so the included SQL/backend setup works together.
