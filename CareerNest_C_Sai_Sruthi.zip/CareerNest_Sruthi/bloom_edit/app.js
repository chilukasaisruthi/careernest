const express = require("express");
const mysql = require("mysql2");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

const imageDir = path.join(__dirname, "public", "images");
fs.mkdirSync(imageDir, { recursive: true });
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, imageDir),
  filename: (_req, file, cb) => cb(null, `${Date.now()}-${file.originalname.replace(/[^a-zA-Z0-9._-]/g, "-")}`)
});
const upload = multer({
  storage,
  limits: { fileSize: 3 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => /^image\/(jpeg|png|webp|gif|svg\+xml)$/.test(file.mimetype)
    ? cb(null, true)
    : cb(new Error("Upload a JPG, PNG, WEBP, GIF, or SVG image."))
});

const db = mysql.createConnection({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD ?? "root",
  database: process.env.DB_NAME || "bloomhire"
});

const query = (sql, values = []) => new Promise((resolve, reject) => {
  db.query(sql, values, (err, result) => err ? reject(err) : resolve(result));
});
const handleError = (res, err) => {
  console.error(err);
  res.status(500).json({ error: err.message || "Something went wrong." });
};
function removeOldImage(imagePath) {
  if (!imagePath || !imagePath.startsWith("/images/")) return;
  const full = path.join(__dirname, "public", imagePath.replace(/^\//, ""));
  if (fs.existsSync(full) && path.basename(full) !== "company-placeholder.svg") fs.unlink(full, () => {});
}

// Safely upgrade an existing jobs table without deleting existing records.
async function ensureCompatibleTable() {
  const columns = await query("SHOW COLUMNS FROM jobs");
  const names = new Set(columns.map(c => c.Field));
  if (!names.has("image")) {
    await query("ALTER TABLE jobs ADD COLUMN image VARCHAR(255) DEFAULT '/images/company-placeholder.svg'");
  }
  if (!names.has("created_at")) {
    await query("ALTER TABLE jobs ADD COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
  }
  const required = ["job_id", "title", "company", "location", "salary", "skill", "interviewdate"];
  const missing = required.filter(name => !names.has(name));
  if (missing.length) throw new Error(`Your jobs table is missing these columns: ${missing.join(", ")}. Please add them in MySQL Workbench.`);
}

app.get("/api/jobs", async (_req, res) => {
  try { res.json(await query("SELECT * FROM jobs ORDER BY created_at DESC, job_id DESC")); }
  catch (e) { handleError(res, e); }
});
app.get("/api/jobs/:id", async (req, res) => {
  try {
    const rows = await query("SELECT * FROM jobs WHERE job_id = ?", [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: "Job not found." });
    res.json(rows[0]);
  } catch (e) { handleError(res, e); }
});
app.post("/api/jobs", upload.single("companyImage"), async (req, res) => {
  try {
    const { title, company, location, salary, skill, interviewdate } = req.body;
    if (!title || !company || !location || !skill || !interviewdate)
      return res.status(400).json({ error: "Please complete title, company, location, skill, and interview date." });
    const image = req.file ? `/images/${req.file.filename}` : "/images/company-placeholder.svg";
    const r = await query("INSERT INTO jobs (title, company, location, salary, skill, interviewdate, image) VALUES (?, ?, ?, ?, ?, ?, ?)",
      [title, company, location, salary || "", skill, interviewdate, image]);
    res.status(201).json({ message: "Job created successfully.", job_id: r.insertId });
  } catch (e) { handleError(res, e); }
});
app.put("/api/jobs/:id", upload.single("companyImage"), async (req, res) => {
  try {
    const rows = await query("SELECT * FROM jobs WHERE job_id = ?", [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: "Job not found." });
    const old = rows[0], b = req.body;
    const image = req.file ? `/images/${req.file.filename}` : (old.image || "/images/company-placeholder.svg");
    await query("UPDATE jobs SET title=?, company=?, location=?, salary=?, skill=?, interviewdate=?, image=? WHERE job_id=?",
      [b.title || old.title, b.company || old.company, b.location || old.location, b.salary ?? old.salary,
       b.skill || old.skill, b.interviewdate || old.interviewdate, image, req.params.id]);
    if (req.file) removeOldImage(old.image);
    res.json({ message: "Job updated successfully." });
  } catch (e) { handleError(res, e); }
});
app.delete("/api/jobs/:id", async (req, res) => {
  try {
    const rows = await query("SELECT * FROM jobs WHERE job_id = ?", [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: "Job not found." });
    await query("DELETE FROM jobs WHERE job_id = ?", [req.params.id]);
    removeOldImage(rows[0].image);
    res.json({ message: "Job deleted successfully." });
  } catch (e) { handleError(res, e); }
});
app.use((err, _req, res, _next) => res.status(400).json({ error: err.message || "Invalid request." }));

db.connect(async err => {
  if (err) {
    console.error("MySQL connection failed:", err.message);
    console.error("Check that MySQL is running, database 'bloomhire' exists, and DB_PASSWORD in app.js matches your MySQL password.");
    process.exitCode = 1;
    return;
  }
  try {
    await ensureCompatibleTable();
    console.log("Connected to MySQL database: bloomhire");
    app.listen(PORT, () => console.log(`CareerNest is running at http://localhost:${PORT}`));
  } catch (e) {
    console.error("Database table setup failed:", e.message);
    console.error("In MySQL Workbench, make sure bloomhire has a jobs table with job_id, title, company, location, salary, skill, and interviewdate.");
    process.exitCode = 1;
    db.end();
  }
});
