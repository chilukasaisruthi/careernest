
const $ = (s) => document.querySelector(s);

const esc = (v) =>
    String(v ?? "").replace(/[&<>"']/g, (c) => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    }[c]));

const money = (v) => (v ? esc(v) : "Not specified");

const date = (v) =>
    v
        ? new Date(
              String(v).slice(0, 10) + "T00:00:00"
          ).toLocaleDateString()
        : "Not set";


// API Helper
async function api(url, options = {}) {
    const r = await fetch(url, options);

    const d = (
        r.headers.get("content-type") || ""
    ).includes("json")
        ? await r.json()
        : await r.text();

    if (!r.ok) {
        throw Error(
            d.error || d || "Request failed"
        );
    }

    return d;
}


// Status Message Helper
function showStatus(el, msg, type = "success") {
    if (el) {
        el.textContent = msg;
        el.className = `status show ${type}`;
    }
}


// Job Card
function jobCard(j) {
    return `
        <article class="job-card">

            <div class="company-row">
                <img
                    class="company-img"
                    src="${esc(j.image || "/images/company-placeholder.svg")}"
                    alt=""
                    onerror="this.src='/images/company-placeholder.svg'"
                >

                <div>
                    <strong>${esc(j.company)}</strong>

                    <div class="company">
                        📍 ${esc(j.location)}
                    </div>
                </div>
            </div>

            <h3>${esc(j.title)}</h3>

            <div class="chips">
                <span class="chip pink">
                    ${esc(j.skill)}
                </span>
            </div>

            <div class="salary">
                ${money(j.salary)}
            </div>

            <p class="company">
                Interview: ${date(j.interviewdate)}
            </p>

            <a
                class="btn soft"
                href="listOne.html?id=${j.job_id}"
            >
                View details ↗
            </a>

        </article>
    `;
}


// Job Table Row
function jobRow(j) {
    return `
        <tr>
            <td>${j.job_id}</td>
            <td>${esc(j.title)}</td>
            <td>${esc(j.company)}</td>
            <td>${esc(j.location)}</td>
            <td>${money(j.salary)}</td>
            <td>${esc(j.skill)}</td>
            <td>${date(j.interviewdate)}</td>

            <td>
                <div class="actions">

                    <a
                        class="btn soft"
                        href="listOne.html?id=${j.job_id}"
                    >
                        View
                    </a>

                    <a
                        class="btn"
                        href="update.html?id=${j.job_id}"
                    >
                        Edit
                    </a>

                    <a
                        class="btn danger"
                        href="delete.html?id=${j.job_id}"
                    >
                        Delete
                    </a>

                </div>
            </td>
        </tr>
    `;
}


// Load Homepage
async function loadHome() {
    const target = $("#featuredJobs");

    if (!target) return;

    try {
        const jobs = await api("/api/jobs");

        $("#jobCount").textContent = jobs.length;

        $("#companyCount").textContent =
            new Set(jobs.map((j) => j.company)).size;

        $("#categoryCount").textContent =
            new Set(jobs.map((j) => j.skill)).size;

        target.innerHTML = jobs.length
            ? jobs.slice(0, 3).map(jobCard).join("")
            : `
                <div class="empty">
                    No jobs yet. Add the first listing.
                </div>
            `;

    } catch (e) {
        target.innerHTML = `
            <div class="empty">
                ${esc(e.message)}
                <br>
                Check MySQL and run schema.sql.
            </div>
        `;
    }
}


// Load All Jobs
async function loadJobs() {
    const body = $("#jobsBody");

    if (!body) return;

    try {
        window.allJobs = await api("/api/jobs");

        renderJobs(window.allJobs);

        populateFilter(
            "#filterLocation",
            window.allJobs.map((j) => j.location),
            "locations"
        );

        populateFilter(
            "#filterSkill",
            window.allJobs.map((j) => j.skill),
            "skills"
        );

        populateFilter(
            "#filterSalary",
            window.allJobs.map((j) => j.salary),
            "salary ranges"
        );

    } catch (e) {
        body.innerHTML = `
            <tr>
                <td colspan="8" class="empty">
                    ${esc(e.message)}
                </td>
            </tr>
        `;
    }
}


// Render Job Table
function renderJobs(jobs) {
    const body = $("#jobsBody");

    if (!body) return;

    body.innerHTML = jobs.length
        ? jobs.map(jobRow).join("")
        : `
            <tr>
                <td colspan="8" class="empty">
                    No matching jobs.
                    Add a listing to get started.
                </td>
            </tr>
        `;

    const count = $("#resultCount");

    if (count) {
        count.textContent =
            `${jobs.length} job${jobs.length === 1 ? "" : "s"} found`;
    }
}


// Populate Filter Dropdowns
function populateFilter(id, values, label) {
    const el = $(id);

    if (!el) return;

    const old = el.value;

    el.innerHTML = `
        <option value="">All ${label}</option>
    ` + [...new Set(values.filter(Boolean))]
        .sort()
        .map(
            (v) => `
                <option value="${esc(v)}">
                    ${esc(v)}
                </option>
            `
        )
        .join("");

    el.value = old;
}


// Apply Job Filters
function applyJobFilters() {
    const term = (
        $("#searchJobs")?.value || ""
    ).toLowerCase().trim();

    const loc = $("#filterLocation")?.value || "";
    const skill = $("#filterSkill")?.value || "";
    const salary = $("#filterSalary")?.value || "";

    renderJobs(
        (window.allJobs || []).filter((j) =>
            [
                j.title,
                j.company,
                j.location,
                j.salary,
                j.skill
            ]
                .join(" ")
                .toLowerCase()
                .includes(term) &&
            (!loc || j.location === loc) &&
            (!skill || j.skill === skill) &&
            (!salary || j.salary === salary)
        )
    );
}


// Fill Job Form
function fillForm(j) {
    for (const k of [
        "title",
        "company",
        "location",
        "salary",
        "skill",
        "interviewdate"
    ]) {
        const el = $(`[name="${k}"]`);

        if (el) {
            el.value =
                k === "interviewdate"
                    ? String(j[k] || "").slice(0, 10)
                    : (j[k] || "");
        }
    }

    const im = $("#currentImage");

    if (im) {
        im.src = j.image || "/images/company-placeholder.svg";
        im.hidden = false;
    }
}


// Fill Job ID Dropdown
async function fillSelect(select, chosen) {
    const jobs = await api("/api/jobs");

    select.innerHTML = `
        <option value="">Choose a job…</option>
    ` + jobs.map(
        (j) => `
            <option value="${j.job_id}">
                #${j.job_id} — ${esc(j.title)} · ${esc(j.company)}
            </option>
        `
    ).join("");

    if (chosen) {
        select.value = chosen;
    }

    return jobs;
}


// Initialize Insert and Update Forms
function initForm() {
    const form = $("#jobForm");

    if (!form) return;

    const status = $("#status");
    const params = new URLSearchParams(location.search);
    const id = params.get("id");
    const edit = form.dataset.mode === "update";
    const select = $("#jobSelect");

    if (edit && select) {
        fillSelect(select, id)
            .then((jobs) => {
                if (id) {
                    const j = jobs.find(
                        (x) => String(x.job_id) === id
                    );

                    if (j) fillForm(j);
                }
            })
            .catch((e) =>
                showStatus(status, e.message, "error")
            );

        select.addEventListener("change", async () => {
            if (select.value) {
                try {
                    fillForm(
                        await api("/api/jobs/" + select.value)
                    );
                } catch (e) {
                    showStatus(status, e.message, "error");
                }
            }
        });
    }

    const file = $('[name="companyImage"]');

    if (file) {
        file.addEventListener("change", () => {
            const p = $("#imagePreview");

            if (file.files[0] && p) {
                p.src = URL.createObjectURL(file.files[0]);
                p.hidden = false;
            }
        });
    }

    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        const btn = form.querySelector('[type="submit"]');
        const originalText = btn.textContent;

        btn.disabled = true;

        if (edit) {
            btn.innerHTML = `
                <span class="spinner"></span>
                Updating job…
            `;

            showStatus(
                status,
                "Updating job details…",
                "success"
            );
        } else {
            btn.textContent = "Publishing job…";
        }

        try {
            const chosen = edit
                ? (select?.value || id)
                : null;

            if (edit && !chosen) {
                throw Error("Choose a job to update.");
            }

            const result = await api(
                edit
                    ? "/api/jobs/" + chosen
                    : "/api/jobs",
                {
                    method: edit ? "PUT" : "POST",
                    body: new FormData(form)
                }
            );

            showStatus(status, result.message);

            if (!edit) {
                form.reset();

                if ($("#imagePreview")) {
                    $("#imagePreview").hidden = true;
                }
            } else {
                history.replaceState(
                    {},
                    "",
                    `update.html?id=${chosen}`
                );
            }

        } catch (err) {
            showStatus(status, err.message, "error");

        } finally {
            btn.disabled = false;
            btn.textContent = originalText;
        }
    });
}


// Initialize Find Job Page
function initFind() {
    const form = $("#findForm");

    if (!form) return;

    const params = new URLSearchParams(location.search);
    const select = $("#jobId");

    fillSelect(select, params.get("id"))
        .catch((e) =>
            showStatus($("#status"), e.message, "error")
        );

    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        const box = $("#jobDetails");
        const status = $("#status");

        box.innerHTML = "";

        try {
            const j = await api(
                "/api/jobs/" +
                encodeURIComponent($("#jobId").value.trim())
            );

            box.innerHTML = `
                ${jobCard(j)}

                <div class="btn-row">
                    <a
                        class="btn"
                        href="update.html?id=${j.job_id}"
                    >
                        Edit
                    </a>

                    <a
                        class="btn danger"
                        href="delete.html?id=${j.job_id}"
                    >
                        Delete
                    </a>
                </div>
            `;

            showStatus(status, "Job found.");

        } catch (err) {
            showStatus(status, err.message, "error");
        }
    });
}


// Initialize Delete Job Page
function initDelete() {
    const form = $("#deleteForm");

    if (!form) return;

    const select = $("#jobSelect");
    const status = $("#status");
    const params = new URLSearchParams(location.search);

    fillSelect(select, params.get("id"))
        .then((jobs) => {
            const update = () => {
                const j = jobs.find(
                    (x) => String(x.job_id) === select.value
                );

                $("#jobInfo").innerHTML = j
                    ? `
                        <h3>${esc(j.title)}</h3>
                        <p>
                            ${esc(j.company)} ·
                            ${esc(j.location)}
                        </p>
                        <p>
                            <b>Skills:</b> ${esc(j.skill)}
                        </p>
                        <p>
                            <b>Interview date:</b>
                            ${date(j.interviewdate)}
                        </p>
                    `
                    : `
                        <p class="company">
                            Select a job to review its details.
                        </p>
                    `;

                $("#deleteButton").disabled = !j;
            };

            select.addEventListener("change", update);
            update();

            form.addEventListener("submit", async (e) => {
                e.preventDefault();

                if (
                    !select.value ||
                    !confirm(
                        "Delete this job listing permanently?"
                    )
                ) {
                    return;
                }

                const btn = $("#deleteButton");
                const original = btn.textContent;

                btn.disabled = true;

                btn.innerHTML = `
                    <span class="spinner"></span>
                    Deleting job…
                `;

                showStatus(
                    status,
                    "Deleting job…",
                    "success"
                );

                try {
                    const r = await api(
                        "/api/jobs/" + select.value,
                        { method: "DELETE" }
                    );

                    showStatus(status, r.message);

                    select.value = "";
                    update();

                } catch (err) {
                    showStatus(status, err.message, "error");

                } finally {
                    btn.disabled = false;
                    btn.textContent = original;
                }
            });
        })
        .catch((e) =>
            showStatus(status, e.message, "error")
        );
}


// Initialize All Pages
document.addEventListener("DOMContentLoaded", () => {
    loadHome();
    loadJobs();
    initForm();
    initFind();
    initDelete();

    $("#searchJobs")?.addEventListener(
        "input",
        applyJobFilters
    );

    [
        "#filterLocation",
        "#filterSkill",
        "#filterSalary"
    ].forEach((id) =>
        $(id)?.addEventListener("change", applyJobFilters)
    );
});
