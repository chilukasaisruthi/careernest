CREATE DATABASE IF NOT EXISTS bloomhire;
USE bloomhire;

CREATE TABLE IF NOT EXISTS jobs (
  job_id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(150) NOT NULL,
  company VARCHAR(150) NOT NULL,
  location VARCHAR(120) NOT NULL,
  salary VARCHAR(80) DEFAULT '',
  skill VARCHAR(255) NOT NULL,
  interviewdate DATE NOT NULL,
  image VARCHAR(255) DEFAULT '/images/company-placeholder.svg',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Existing tables are not deleted. The app adds missing image/created_at columns at startup.
